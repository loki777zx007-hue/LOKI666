# LOKI 666 Android UI wrapper

This is a starter Android project that packages the existing LOKI 666 HTML interface inside an Android WebView.

## Important limitation
This APK contains the interface only. It does NOT create a VPN tunnel and the Connect button is not connected to a Hysteria 2 engine. A working VPN requires a compatible Hysteria 2 implementation, Android `VpnService` integration, configuration parsing, permissions, and real-device testing.

## Build on an Android phone using GitHub Actions
1. Extract this ZIP.
2. In your browser, create a new GitHub repository named `LOKI666-Android`.
3. Upload all files and folders from this project, including `.github/workflows/build-apk.yml`.
4. Open the repository's **Actions** tab and run **Build LOKI 666 APK** (or push to `main`).
5. Open the completed workflow run, download the `LOKI666-debug-apk` artifact, extract it, and install `app-debug.apk` on your Android phone.
6. If GitHub asks you to allow Actions for the repository, enable them.

## Notes
- This is a debug APK for testing, not a Play Store release.
- The build workflow uses Gradle installed on the runner, so no local Gradle wrapper is included.
- Review dependencies and source before using a cloud build service.
- Do not put active proxy tokens or private server credentials in a public repository.
